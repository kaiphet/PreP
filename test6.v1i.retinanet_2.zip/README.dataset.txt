# test6 > 2023-01-10 10:04pm
https://universe.roboflow.com/kaiphet-thoopphutsa/test6-hujbt

Provided by a Roboflow user
License: CC BY 4.0

